require('ui/chrome')
.setNavBackground('#222222')
.setTabs([{
  id: '',
  title: 'Preflight'
}])
.setRootTemplate(require('plugins/elastic-preflight/index.html'));

require('plugins/elastic-preflight/lib/controllers/mainCtrl.js');
require('plugins/elastic-preflight/main.less');
require('ui/styles/base.less');
require('ui/styles/theme.less');
