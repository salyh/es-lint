module.exports =  function (kibana) {
  return new kibana.Plugin({
    require: ['elasticsearch'],
    id: 'elastic-preflight',
    uiExports: {
      app: {
        title: 'Preflight',
        description: 'Elasticsearch Preflight Check - Sanitychecks for your cluster',
        main: 'plugins/elastic-preflight/app'
        //autoload: kibana.autoload.styles
      }
    },
  });
};
